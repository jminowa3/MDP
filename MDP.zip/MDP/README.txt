1. run java -jar rl_sim.jar to start the gui
2. unzip the big and small sample
3. load them into the policy iteration
4. initialize then execute to run the algorithms on the MDPs created
Repeat for value iteration, q-learning algorithms

All credit for graphs and grids created go to the creators for the reinforcement learning gui, taken from https://www.cs.cmu.edu/~awm/rlsim/

Github link:
https://github.com/jminowa3/MDP