# MDP
1. run java -jar rl_sim.jar to start the gui
2. unzip the big and small sample
3. load them into the policy iteration
4. Repeat for value iteration, and q-learning algorithms
3. initialize then execute to run the algorithms on the MDPs created
